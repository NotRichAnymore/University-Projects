#ifndef ETMTRANSPORTC_H
#define ETMTRANSPORTC_H


class etmtransportc
{
public:
    etmtransportc();
};

#endif // ETMTRANSPORTC_H
